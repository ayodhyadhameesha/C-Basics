#include <iostream>

using namespace std;

int main()
{
    int ayod[2][3]={{2,4,6},{3,5,7}};
    cout <<ayod[2,2];


    return 0;
}
