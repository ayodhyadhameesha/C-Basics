/* Stub for HID.cpp */

#include <HID.cpp>