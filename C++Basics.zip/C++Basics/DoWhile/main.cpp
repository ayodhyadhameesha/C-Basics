#include <iostream>

using namespace std;

int main()
{
  int x=0;

do{


    cout<< "Ayodhya";
    x=x+1;
}while(x>5);

return 0;
}
