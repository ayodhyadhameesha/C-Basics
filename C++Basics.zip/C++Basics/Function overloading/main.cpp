#include <iostream>

using namespace std;

void Print(int a){
cout << "Print the integer"<<a<<endl;
}
void Print (float b){
cout << "Print the float" <<b<<endl;
}
int main()
{
    int a=54;
    float b=32.45;

    Print(a);
    Print (b);


    return 0;
}
