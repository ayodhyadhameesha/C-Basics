#include <iostream>

using namespace std;
void ayodhya (int a ,int b);

int main()
{
ayodhya(2,3);


  return 0;
}

void  ayodhya(int a ,int b){
    cout << "my name is khan";
    cout<<a*b;


}


