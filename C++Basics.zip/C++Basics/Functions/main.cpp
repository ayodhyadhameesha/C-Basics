#include <iostream>

using namespace std;


int cal(int x,int y);

int main()
{

 cal(8,9);

return 0;
}

int cal(int x,int y){

 int sum;
 sum=x+y;
 return sum;

}

