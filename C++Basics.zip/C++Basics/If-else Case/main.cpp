#include <iostream>

using namespace std;

int main()
{ int x;

cout << "Please enter your age" <<endl;
cin>>x;
if (x>=18) {
    cout<< "You are eligible" <<endl;
}
    else
        if(17>x&&x>16)
    {
        cout << "You are good" <<endl;
    }
    else
        if (12<x&&x<16){
        cout << "You are best" << endl;
        }
    else
        cout<< "Go home"<<endl;

return 0;
}
