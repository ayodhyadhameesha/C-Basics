#include <iostream>

using namespace std;

int main()
{
   int age;
   int money;

   cin>>age;
   cin>>money;

   if (age>21&&money>500)
    {
        cout<< "You are in" <<endl;

    }
        else
            cout << "You are out" <<endl;


}
