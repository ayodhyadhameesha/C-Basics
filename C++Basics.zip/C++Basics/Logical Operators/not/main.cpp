#include <iostream>

using namespace std;

int main()
{


    if (!6 <= 4)
        {
        cout<< "Dog";
        }

    else
        cout<< "en";




    return 0;
}
