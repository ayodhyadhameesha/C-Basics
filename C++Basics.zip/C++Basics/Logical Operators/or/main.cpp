#include <iostream>

using namespace std;

int main()
{
    int x;
    cin>>x;

    if (x<5||x>10)
        {
        cout<< "Dog";
        }

    else
        cout<< "en";




    return 0;
}
