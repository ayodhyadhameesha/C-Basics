#include <iostream>

using namespace std;

int main()
{
    int a;
    cout<< "Please enter your mark\n";
    cin>>a;
    if (a>=75)
        cout<<"A pass"<<endl;
    else if (a>=65&&a<75)
         cout<< "B pass"<<endl;
    else if (a<=55&&a>45)
          cout<< "C pass"<< endl;
    else
        cout<<"Fail"<<endl;
    return 0;
}
