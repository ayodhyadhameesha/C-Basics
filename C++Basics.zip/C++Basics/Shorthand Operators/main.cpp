#include <iostream>

using namespace std;

int main()
{
   int x=100;
//addition
   x+=30;
   cout<<x<<endl;
//addition
   int y=90;
   y=+80;
   cout <<y<<endl;
//subtraction
   int z=70;
   z-=40;

   cout<<z<<endl;

   int s=70;
   s=-30;
   cout<<s<<endl;

   int a=10;
//% shows the remaining value after division
   a%=3;
   cout<<a<<endl;



}
