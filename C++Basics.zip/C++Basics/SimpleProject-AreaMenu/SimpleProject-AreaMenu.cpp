#include<iostream>
#include<stdlib.h>

using namespace std;

void readRecLenWid(int &recLength, int &recWidth);
int calRecArea(int recLength, int recWidth);
void displayRecArea(int recArea);

void readTraingleinfo(int &triBase, int &triHeight);
int caltriArea(int triArea);
int main()
{
    int option, sqLength, sqArea, recLength, recWidth, recArea,triBase,triHeight,;
    cout << "Area of the Shapes\n";
    cout << "******************\n\n";
    cout << "1. Square\n";
    cout << "2. Rectangle\n";
    cout << "3. Triangle\n";
    cout << "4. Circle\n\n";
    cout << "Enter your option: ";
    cin >> option;
    system ("CLS");     //To clear the screen
    switch(option)
    {
        case 1: cout << "\n\n";
                cout << "Enter Length: ";
                cin >> sqLength;
                sqArea = sqLength * sqLength;
                cout << "Area of the square: " << sqArea << endl;
                break;
        case 2: readRecLenWid(recLength, recWidth);
                recArea = calRecArea(recLength, recWidth);
                displayRecArea(recArea);
                break;
         case 3:readTraingleinfo(triBase,triHeight);
                displaytriArea=triBase*triHeight;



        default: cout << "Wrong code \n";
    }
    return 0;
}

void readRecLenWid(int &recLength, int &recWidth)
{
    cout << "\n\n";
    cout << "Enter length : ";
	cin >> recLength;
	cout << "Enter width: ";
	cin >> recWidth;
}

int calRecArea(int recLength, int recWidth)
{
    int area;
    area = recLength * recWidth;
    return area;
}

void displayRecArea(int recArea)
{
    cout << "Area of Rectangle: " << recArea << endl;
}
void readTraingleinfo(int &triBase,int &triHeight){
cout<<"\n\n";
cout<< "Enter the Base length"<<endl;
cin>>triBase;
cout<< "Enter the Perpendicular Height"<<endl;
cin>>triHeight;
}

int displaytriArea(int triArea){
 triArea=0.5*triBase*triHeight;

}

