#include <iostream>

using namespace std;

int main()
{
    int day;
    cout<< "Enter a day"<<endl;
    cin>>day;
    switch(day)
case 1:
    cout<< "Weekend day"<<endl;
    break;
case 2:
    cout<< "Weekday";
    break;
case 3:
    cout<< "Weekday";
    break;
case 4:
    cout<< "Weekday";
    break;
case 5:
    cout<< "Weekday";
    break;
case 6:
    cout<< "Weekday";
case 7:
    cout<< "Weekend"<<endl;
    break;
default:
    cout<< "Wrong operation"<<endl;


    return 0;
}
