#include <iostream>
using namespace std;

int main()
{
    int age;
    cout << "Please enter your age"<<endl;
    cin>>age;

    switch(age){

    case 16:
    cout<< "You are a teenager"<<endl;
    break;

    case 18:
        cout << "You are about to be an adult"<<endl;
        break;
    case 20:
        cout << "You are an adult" <<endl;
        break;

    default:
        cout << "Go home and sleep" <<endl;



    }
    return 0;
}

